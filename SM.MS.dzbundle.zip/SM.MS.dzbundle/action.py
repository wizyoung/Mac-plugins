# Dropzone Action Info
# Name: SM.MS
# Description: upload your image to sm.ms
# Handles: Files
# Creator: wizyoung
# URL: https://wizyoung.github.io
# Events: Clicked, Dragged
# KeyModifiers: Command, Option, Control, Shift
# SkipConfig: No
# RunsSandboxed: Yes
# Version: 1.0
# MinDropzoneVersion: 3.5

import sys
import requests
import time

reload(sys)
sys.setdefaultencoding('utf8')

def upload(img_path):
    s = requests.Session()
    f = open(img_path, 'rb')
    data = {'smfile': f}
    z = s.post(url='https://sm.ms/api/upload', files=data)
    f.close()
    res = z.json()
    return res['data']['url']

def dragged():
    img_path = items[0]

    dz.determinate(True)
    dz.percent(10)
    time.sleep(1)
    dz.percent(50)
    try:
        url = upload(img_path)
        dz.percent(100)
        dz.text(url)
        dz.finish("The image url has been copied to the clipboard.")
    except:
        dz.fail('Image upload failed, try again!')
 
def clicked():
    # This method gets called when a user clicks on your action
    dz.finish("You clicked me!")
    dz.url(False)
