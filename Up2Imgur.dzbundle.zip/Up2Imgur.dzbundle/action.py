# coding: utf-8
# Dropzone Action Info
# Name: Up2Imgur
# Description: upload your image to imugr.com
# Handles: Files
# Creator: wizyoung
# URL: https://wizyoung.github.io
# Events: Clicked, Dragged
# KeyModifiers: Command, Option, Control, Shift
# SkipConfig: No
# RunsSandboxed: Yes
# Version: 1.0
# MinDropzoneVersion: 3.5

import sys
import requests
import time
import random

reload(sys)
sys.setdefaultencoding('utf8')

def upload(img_path):
    f = open(img_path, 'rb')
    ClientIDs = ['598d1305f5c9859', '295d430405aa8dc']
    r = requests.post(url='https://api.imgur.com/3/image',
                  data={'image': f.read(), 'type': 'file'},
                  headers={'authorization': 'Client-ID ' + ClientIDs[random.randint(0, len(ClientIDs)-1)]})
    f.close()
    res = r.json()
    return res['data']['link']

def dragged():
    # 拖拽文件进去后, 返回items是个list，一般只有一个值，就是
    # 文件路径
    img_path = items[0]

    dz.percent(10)
    time.sleep(1)
    dz.percent(50)
    try:
        url = upload(img_path)
        dz.percent(100)
        # 输出到剪贴板
        dz.text(url)
        # 右上角bubble弹窗
        dz.finish("The image url has been copied to the clipboard.")
    except:
        dz.fail('Image upload failed, try again!')

def clicked():
    dz.finish("You clicked me!")
    dz.url(False)
