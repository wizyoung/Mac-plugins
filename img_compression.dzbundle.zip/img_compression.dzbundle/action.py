# coding: utf-8
# Dropzone Action Info
# Name: 图像压缩
# Description: compress your image
# Handles: Files
# Creator: wizyoung
# URL: https://wizyoung.github.io
# Events: Clicked, Dragged
# KeyModifiers: Command, Option, Control, Shift
# SkipConfig: No
# RunsSandboxed: Yes
# Version: 1.0
# MinDropzoneVersion: 3.5

import os

def compress(img_path):
    shell_script = './pngquant "' + img_path + '" --speed 1 --skip-if-larger --ext _new.png'
    print shell_script
    os.system(shell_script)

def dragged():
    item_len = len(items)

    for i in range(item_len):
        img_path = items[i]
        compress(img_path)
        if i == item_len - 1:
            dz.finish('Success!')
 
def clicked():
    # This method gets called when a user clicks on your action
    dz.finish("You clicked me!")
    dz.url(False)
