# coding: utf-8
import argparse

import re
from urllib import unquote

# reload(sys)
# sys.setdefaultencoding('utf8')

parser = argparse.ArgumentParser()
parser.add_argument('query', nargs='?', default=None)
args = parser.parse_args()

query = args.query
query = unquote(args.query)

res = re.sub(r'.*comment.*\n', '', query)
res = re.sub(r'.*file.*\n', '', res)
res = re.sub(r'.*timestamp.*\n', '', res)
res = re.sub(r'.*url.*\n', '', res)
res = re.sub(r'.*note.*\n', '', res)

print res




