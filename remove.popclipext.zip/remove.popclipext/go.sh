#!/bin/bash

python remove.py $POPCLIP_URLENCODED_TEXT
