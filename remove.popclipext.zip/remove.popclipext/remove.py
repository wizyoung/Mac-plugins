# coding: utf-8
import argparse
import sys
import re
from urllib import unquote

reload(sys)
sys.setdefaultencoding('utf8')

parser = argparse.ArgumentParser()
parser.add_argument('query', nargs='?', default=None)
args = parser.parse_args()

query = args.query
query = unquote(args.query)
query = query.decode('utf-8')

res = re.sub(r' {2,}', '', query)
res = re.sub(r'\n', '', res)
res = re.sub(ur'(?<=[\u4e00-\u9fa5]) +','', res)
res = re.sub(ur' +(?=[\u4e00-\u9fa5])','', res)

print res




